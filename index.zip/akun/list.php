
<ul >
    <li>Nama : <ul>
                <li>Barbar</li>
                </ul>
    </li>
    <li>Email : <ul>
                <li>barbar@barbar.com</li>
                </ul>
    </li>
    <li>Tempat, Tanggal Lahir : <ul>
                <li>Jogja, 06 September 1998</li>
                </ul>
    </li>
    <li>Kutipan Favorit : <ul>
                <li>Belajar dan berubah</li>
                </ul>
    </li>
</ul>