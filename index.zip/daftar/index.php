<?php
require_once('..'.DIRECTORY_SEPARATOR.'base'.DIRECTORY_SEPARATOR.'base.php');

echo '<script> window.location.href = "'.BASE_URL.'"; </script>'
?>