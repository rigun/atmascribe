<div class="row">
<div class="col-12">
        <div class="box-data-user">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Ttl</th>
                        <th>Kutipan</th>
                        <th>Pengaturan</th>
                    </tr>
                </thead>
                <tbody id="dataReportTable">
                </tbody>
            </table>
        </div>
        </div>
</div>