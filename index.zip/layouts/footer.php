    </div>
                </div>
            </div>
        </div>
    </section>
</body>
<script src="<?php echo BASE_URL.'/bower_components/jquery/dist/jquery.min.js'; ?>"></script>
<script src="<?php echo BASE_URL.'/bower_components/boostrap/dist/js/bootstrap.min.js'; ?>"></script>
<script src="<?php echo BASE_URL.'/js/style.js'; ?>"></script>
</html>